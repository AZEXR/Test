const {
  readdirSync
} = require("fs");

module.exports = async (client) => {
  try {
    let amount = 0;
    readdirSync("./commands/").forEach((dir) => {
      const commands = readdirSync(`./commands/${dir}/`).filter((file) => file.endsWith(".js"));
      for (let file of commands) {
        let pull = require(`../commands/${dir}/${file}`);
        if (pull.name) {
          client.commands.set(pull.name, pull);
          amount++;
        } else {
          try {
            const stringlength = 69;
            console.log(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.red)
            console.log(`     ┃ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + `Command Not Loaded`.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length - `Command Not Loaded`.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + ` /--/ ${file} /--/ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length - ` /--/ ${file} /--/ `.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.red)
            console.log(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.red)
            // console.log(${file}, 'error -> missing a help.name, or help.name is not a string.'.brightRed);
          } catch {
            /* */ }
          continue;
        }
        if (pull.aliases && Array.isArray(pull.aliases)) pull.aliases.forEach((alias) => client.aliases.set(alias, pull.name));
      }
    });
    console.log(`${amount} Commands Loaded`.brightGreen);
  } catch (e) {
    console.log(String(e.stack).bgRed)
  }
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */