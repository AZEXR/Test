module.exports = async () => {
  // process.on('beforeExit', (code) => { // If You Want You Can Use
  //   console.log('[antiCrash] :: [beforeExit]');
  //   console.log(code);
  // });
  // process.on('exit', (error) => { // If You Want You Can Use
  //   console.log('[antiCrash] :: [exit]');
  //   console.log(error);
  // });
  process.on('multipleResolves', (type, promise, reason) => { // Needed
    console.log('[antiCrash] :: [multipleResolves]');
    // console.log(type, promise, reason);
  });
  process.on('unhandledRejection', (reason, promise) => { // Needed
    console.log('[antiCrash] :: [unhandledRejection]');
    console.log(promise, reason);
  });
  // process.on('rejectionHandled', (promise) => { // If You Want You Can Use
  //   console.log('[antiCrash] :: [rejectionHandled]');
  //   console.log(promise);
  // })
  process.on("uncaughtException", (err, origin) => { // Needed
    console.log('[antiCrash] :: [uncaughtException]');
    console.log(err, origin);
  });
  process.on('uncaughtExceptionMonitor', (err, origin) => { // Needed
    console.log('[antiCrash] :: [uncaughtExceptionMonitor]');
    console.log(err, origin);
  });
  // process.on('warning', (warning) => { // If You Want You Can Use
  //   console.log('[antiCrash] :: [warning]');
  //   console.log(warning);
  // });
  // process.on('SIGINT', () => { // If You Want You Can Use
  //   console.log('[antiCrash] :: [SIGINT]');
  // });
};

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */