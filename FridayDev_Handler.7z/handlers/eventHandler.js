const fs = require("fs");
const allevents = [];

module.exports = async (client) => {
  try {
    try {
            const stringlength = 69;
            console.log("\n")
            console.log(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.yellow)
            console.log(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
            console.log(`     ┃ `.bold.yellow + `Welcome to SERVICE HANDLER!`.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - `Welcome to SERVICE HANDLER!`.length) + "┃".bold.yellow)
            console.log(`     ┃ `.bold.yellow + `  /-/ Made By Zedro /-/`.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - `  /-/ Made By Zedro /-/`.length) + "┃".bold.yellow)
            console.log(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
            console.log(`     ┃ `.bold.yellow + `  /-/ Discord: Zedro#2742 /-/`.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - `  /-/ By Discord: Zedro#2742 /-/`.length) + "   ┃".bold.yellow)
            console.log(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
            console.log(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.yellow)
        } catch {
            /* */ }
    let amount = 0;
    const load_dir = (dir) => {
      const event_files = fs.readdirSync(`./events/${dir}`).filter((file) => file.endsWith(".js"));
      for (const file of event_files) {
        try {
          const event = require(`../events/${dir}/${file}`)
          let eventName = file.split(".")[0];
          allevents.push(eventName);
          client.on(eventName, event.bind(null, client));
          amount++;
        } catch (e) {
          console.log(e)
        }
      }
    }
    await ["client", "guild"].forEach(e => load_dir(e));
    console.log(`${amount} Events Loaded`.brightGreen);
  } catch (e) {
    console.log(String(e.stack).bgRed)
  }
};

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */