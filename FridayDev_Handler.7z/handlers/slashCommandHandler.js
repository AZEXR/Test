const {
	readdirSync
} = require("fs");

// const guildId = "";

module.exports = async (client) => {
	let amount = 0;
	const slashCommandsArray = [];
	readdirSync("./slashCommands/").forEach((dir) => {
		const slashCommands = readdirSync(`./slashCommands/${dir}/`).filter((file) => file.endsWith(".js"));
		for (let file of slashCommands) {
			const pull = require(`../slashCommands/${dir}/${file}`);
			if (pull.name) {
				client.slashCommands.set(pull.name, pull);
        if (["MESSAGE", "USER"].includes(pull.type)) delete pull.description;
				amount++;
				slashCommandsArray.push(pull)
			} else {
          try {
            const stringlength = 69;
            console.log(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.red)
            console.log(`     ┃ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + `Slash Command Not Loaded`.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length - `Slash Command Not Loaded`.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + ` /--/ ${file} /--/ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length - ` /--/ ${file} /--/ `.length) + "┃".bold.red)
            console.log(`     ┃ `.bold.red + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.red)
            console.log(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.red)
            // console.log(${file}, 'error -> missing a help.name, or help.name is not a string.'.brightRed);
          } catch {
            /* */}
          continue;
        }
		}
	});
	console.log(`${amount} Slash Commands Loaded`.brightGreen);

	client.on("ready", async () => {
		try {
			// For 1 Server Only
			// await client.guilds.cache.get(guildId).commands.set(slashCommandsArray);
			// For Global Server
			await client.application.commands.set(slashCommandsArray);
		} catch (error) {
			console.log(error)
		}
	})
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */