const config = require(`../../botconfig/config.json`);
const ee = require(`../../botconfig/embed.json`);
const {
	MessageEmbed,
  Collection
} = require("discord.js");

module.exports = async (client, interaction) => {
	try {
		let prefix = `/`;
    
		if (interaction.isCommand()) {
      // await interaction.deferReply({ ephemeral: false }).catch(() => {});
			let command = client.slashCommands.get(interaction.commandName);
			if (!command) return interaction.reply({
				content: "Something Went Wrong",
				ephemeral: true
			});

			if (!interaction.guild.me.permissions.has(["SEND_MESSAGES", "EMBED_LINKS", "READ_MESSAGE_HISTORY"])) return await interaction.member.send({
				embeds: [new MessageEmbed()
					.setTitle(`${client.allEmojis.x} I do not have \`SEND_MESSAGES\`, \`EMBED_LINKS\` & \`READ_MESSAGE_HISTORY\` permission to use \`${prefix}${command.name}\` command!`)
					.setFooter(ee.footertext, ee.footericon)
					.setColor(ee.wrongcolor)
				],
				ephemeral: true
			}).catch((e) => {
				console.log(e)
			});
      if (command.toggleOff) {
          return await interaction.reply({ embeds: [new MessageEmbed()
          .setTitle(`${client.allEmojis.x} That Command Has Been Disabled By The Developers! Please Try Later.`)
          .setColor(ee.wrongcolor)
          ] 
          }).catch((e) => {
						console.log(e)
					});
        }
			if (!interaction.member.permissions.has(command.userPermissions || [])) return await interaction.reply({
				embeds: [new MessageEmbed()
					.setTitle(`${client.allEmojis.x} You do not have \`${command.userPermissions.join(", ")}\` permission to use \`${prefix}${command.name}\` command!`)
					.setFooter(ee.footertext, ee.footericon)
					.setColor(ee.wrongcolor)
				],
				ephemeral: true
			}).catch((e) => {
				console.log(e)
			});
			if (!interaction.guild.me.permissions.has(command.botPermissions || [])) return await interaction.reply({
				embeds: [new MessageEmbed()
					.setTitle(`${client.allEmojis.x} I do not have \`${command.botPermissions.join(", ")}\` permission to use \`${prefix}${command.name}\` command!`)
					.setFooter(ee.footertext, ee.footericon)
					.setColor(ee.wrongcolor)
				],
				ephemeral: true
			}).catch((e) => {
				console.log(e)
			});
      if (onCoolDown(interaction, command)) {
			  return interaction.reply({ephemeral: true,
				embeds: [new MessageEmbed()
				  .setColor(ee.wrongcolor)
          .setTitle(`${client.allEmojis.x} Please wait \`${onCoolDown(interaction, command).toFixed(1)} seconds\` Before using the \`${prefix}${command.name}\` command again!.`)
				  ]
			  });
			}
			command.run(client, interaction, prefix);
		}

    if (interaction.isContextMenu()) {
        // await interaction.deferReply({ ephemeral: false });
        let command = client.slashCommands.get(interaction.commandName);
        if (command) command.run(client, interaction);
    }

	} catch (err) {
		console.log(err)
	}
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */

 function onCoolDown(message, command) {
  if (!message || !message.client) throw "No Message with a valid DiscordClient granted as First Parameter";
  if (!command || !command.name) throw "No Command with a valid Name granted as Second Parameter";
  const client = message.client;
  if (!client.cooldowns.has(command.name)) {
    client.cooldowns.set(command.name, new Collection());
  }
  const now = Date.now();
  const timestamps = client.cooldowns.get(command.name);
  const cooldownAmount = (command.cooldown) * 1000;
  if (timestamps.has(message.member.id)) {
    const expirationTime = timestamps.get(message.member.id) + cooldownAmount;
    if (now < expirationTime) {
      const timeLeft = (expirationTime - now) / 1000;
      return timeLeft
    } else {
      timestamps.set(message.member.id, now);
      setTimeout(() => timestamps.delete(message.member.id), cooldownAmount);
      return false;
    }
  } else {
    timestamps.set(message.member.id, now);
    setTimeout(() => timestamps.delete(message.member.id), cooldownAmount);
    return false;
  }
}