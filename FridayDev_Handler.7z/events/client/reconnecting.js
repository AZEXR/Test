module.exports = async (client) => {
    console.log(`Reconnceting at ${new Date()}.`.bgYellow.black)
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */