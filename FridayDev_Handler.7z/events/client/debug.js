module.exports = async (client, info) => {
  //console.log(String(info).grey);
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */