module.exports = async (client, id) => {
  try {
    const stringlength = 69;
    console.log("\n")
    console.log(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.yellow)
    console.log(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
    console.log(`     ┃ `.bold.yellow + `#${id} Shards Ready!`.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - `#${id} Shards Ready!`.length) + "┃".bold.yellow)
    console.log(`     ┃ `.bold.yellow + ` /--/ ${String(new Date).split(" ", 5).join(" ")} /--/ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - ` /--/ ${String(new Date).split(" ", 5).join(" ")} /--/ `.length) + "┃".bold.yellow)
    console.log(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
    console.log(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.yellow)
  } catch {
    /* */ }
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */