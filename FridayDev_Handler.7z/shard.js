const { ShardingManager } = require("discord.js");

const shards  = new ShardingManager("./bot.js", {
  token: process.env.TOKEN,
  totalShards: "auto",
});

shards.on("shardCreate", async (shard) => console.log(`#${shard.id} Shard Launched [${String(new Date).split(" ", 5).join(" ")}]`))

shards.spawn({amount: shards.totalShards, delay: 5500, timeout: 30000});

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */