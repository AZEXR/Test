const express = require('express');
const app = express();
const port = 3000 || 8080;
app.use(express.static("public"));

app.get('/', (req, res) => {
  try {
    res.sendFile(__dirname + "/index.html")
  } catch {
    /* */ }
});

app.listen(port, () => {
  try {
    const stringlength = 69;
    res.send("\n")
    res.send(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.yellow)
    res.send(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
    res.send(`     ┃ `.bold.yellow + `Connected to Port => ${port}`.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length - `Connected to Port => ${port}`.length) + "┃".bold.yellow)
    res.send(`     ┃ `.bold.yellow + " ".repeat(-1 + stringlength - ` ┃ `.length) + "┃".bold.yellow)
    res.send(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.yellow)
  } catch {
    /* */ }
});

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */