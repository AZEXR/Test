module.exports = async () => {
  try{
      const stringlength = 69;
      console.log("\n")
      console.log(`     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`.bold.yellow)
      console.log(`     ┃ `.bold.yellow + " ".repeat(-1+stringlength-` ┃ `.length)+ "┃".bold.yellow)
      console.log(`     ┃ `.bold.yellow + `Connected to MongoDB Database!`.bold.yellow + " ".repeat(-1+stringlength-` ┃ `.length-`Connected to MongoDB Database!`.length)+ "┃".bold.yellow)
      console.log(`     ┃ `.bold.yellow + " ".repeat(-1+stringlength-` ┃ `.length)+ "┃".bold.yellow)
      console.log(`     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`.bold.yellow)
    }catch{ /* */ }
}

/**
 * @INFO
 * Bot Coded by Blind Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made by Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please mention us Friday Development, when using this Code!
 * @INFO
 */