module.exports = async (client, error) => {
  console.log(String(error).red.dim);
}

/**
 * @INFO
 * Bot Coded by Blind Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made by Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please mention us Friday Development, when using this Code!
 * @INFO
 */