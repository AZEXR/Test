// Commands Module
const config = require('../../botconfig/config.json');
const ee = require('../../botconfig/embed.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: '',
  aliases: [],
  usage: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, message, args) => {}
}
// Commands Module End

// ---------------------------------------------------

// Slash Commands Module
const config = require('../../botconfig/config.json');
const ee = require('../../botconfig/embed.json');
const {
  MessageEmbed
} = require('discord.js');

module.exports = {
  name: '',
  description: '',
  cooldown: 0,
  userPermissions: [],
  botPermissions: [],
  // toggleOff: true,

  run: async (client, interaction) => {}
}
// Slash Commands Module End

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Made By Friday Development | https://discord.gg/8fYUFxMtAq
 * @INFO
 * Please Mention Us Friday Development, When Using This Code!
 * @INFO
 */